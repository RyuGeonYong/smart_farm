import json
import os

#json 파싱
def json_parse(json_data):
    jsonArray_img = json_data.get("images")
    for list in jsonArray_img:
        pl_code = list.get("pl_code")
        pl_step = list.get("pl_step")

    return pl_code, pl_step

def createFolder(directory):
    try:
        if not os.path.exists(directory):
            os.makedirs(directory)
    except OSError:
        print ('Error: Creating directory. ' +  directory)



output_path = 'C:/Users/rgy63/PycharmProjects/YOLOv5/farm_data/pl_step/'
createFolder(output_path)

json_path = "C:/Users/rgy63/PycharmProjects/YOLOv5/farm_data/Validation/tomato_label/"
json_list = os.listdir(json_path)

yolo_list = []
output_file = output_path + "tomato_pl_step.txt"

for i in range(len(json_list)):
    json_file = json_path + json_list[i]

    with open(json_file, 'r', encoding='UTF8') as f:
        json_data = json.load(f)

    print(json_file + " start!")
    pl_code, pl_step = json_parse(json_data)
    yolo = [str(pl_code), str(pl_step)]
    yolo_list.append(" ".join(yolo))

    print(json_file + " done!")


with open(output_file, 'w', encoding='UTF8') as f:
    f.writelines("\n".join(yolo_list))

my_set = set(yolo_list)
my_list = list(my_set)
print(my_list)

print(output_file + " done!")