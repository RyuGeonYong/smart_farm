import json
import cv2
import os

"""
애플망고 : 화아분화기(1), 개화기(2)
방울 토마토 : 영양생장(3) 생육기(4) 착과기(5) 수확기(6)
오이 : 영양생장(7) 개화기(8)
가지 : 영양생장(9) 개화기(10) 수확기(11)
상추 : 영양생장(12) 생육기(13) 착과기(14) 수확기(15)
멜론 : 정식기(16) 영양생장(17) 영양생장기(18) 개화기(19) 과실비대기(20)
파프리카(블로키) : 화아발아기(21) 착과기(22) 과실비대기(23) 과비대성숙기(24) 착색기(25) 수확기(26)
파프리카(코니컬) : 육묘기(27) 정식기(28) 생육기(29) 착과기(30) 과실비대기(31) 수확기(32)
파프리카(미니) : 착과기(33) 과비대성숙기(34) 수확기(35) 
애호박 : 영양생장(36) 생육기(37) 착과기(38)  수확기(39)
딸기 : 꽃눈분화기(40) 개화기(41) 수확기(42)
토마토 : 정식기(43) 영양생장(44) 생육기(45) 착과기(46) 수확기(47)
"""

#json 파싱
def json_parse(json_data):
    bbox_list = []
    jsonArray_img = json_data.get("images")
    for list_info in jsonArray_img:
        pl_code = list_info.get("pl_code")
        pl_step = list_info.get("pl_step")

    jsonArray_ant = json_data.get("annotations")
    for list_info in jsonArray_ant:
        bbox_list.append(list_info.get("bbox"))

    return pl_code, pl_step, bbox_list

def img_parse(img_file):
    img = cv2.imread(img_file)
    h, w, c = img.shape
    return w, h

def farm_class_classify(pl_code, pl_step):
    class_code = -1

    if pl_code == 13:  # 애플망고

        if pl_step == "화아분화기":
            class_code = 0

        elif pl_step == "개화기":
            class_code = 1

    elif pl_code == 20:  # 방울 토마토

        if pl_step == "영양생장":
            class_code = 2

        elif pl_step == "생육기":
            class_code = 3

        elif pl_step == "착과기":
            class_code = 4

        elif pl_step == "수확기":
            class_code = 5

    elif pl_code == 10:  # 오이

        if pl_step == "영양생장":
            class_code = 6

        elif pl_step == "개화기":
            class_code = 7

    elif pl_code == 15:  # 가지

        if pl_step == "영양생장":
            class_code = 8

        elif pl_step == "개화기":
            class_code = 9

        elif pl_step == "수확기":
            class_code = 10

    elif pl_code == 9:  # 상추

        if pl_step == "영양생장":
            class_code = 11

        elif pl_step == "생육기":
            class_code = 12

        elif pl_step == "착과기":
            class_code = 13

        elif pl_step == "수확기":
            class_code = 14

    elif pl_code == 19:  # 멜론

        if pl_step == "정식기":
            class_code = 15

        elif pl_step == "영양생장":
            class_code = 16

        elif pl_step == "영양생장기":
            class_code = 17

        elif pl_step == "개화기":
            class_code = 18

        elif pl_step == "과실비대기":
            class_code = 19

    elif pl_code == 5:  # 파프리카(블로키)

        if pl_step == "화아발아기":
            class_code = 20

        elif pl_step == "착과기":
            class_code = 21

        elif pl_step == "과실비대기":
            class_code = 22

        elif pl_step == "과비대성숙기":
            class_code = 23

        elif pl_step == "착색기":
            class_code = 24

        elif pl_step == "수확기":
            class_code = 25

    elif pl_code == 6:  # 파프리카(코니컬)

        if pl_step == "육묘기":
            class_code = 26

        elif pl_step == "정식기":
            class_code = 27

        elif pl_step == "생육기":
            class_code = 28

        elif pl_step == "착과기":
            class_code = 29

        elif pl_step == "과실비대기":
            class_code = 30

        elif pl_step == "수확기":
            class_code = 31

    elif pl_code == 4:  # 파프리카(미니)

        if pl_step == "착과기":
            class_code = 32

        elif pl_step == "과비대성숙기":
            class_code = 33

        elif pl_step == "수확기":
            class_code = 34

    elif pl_code == 11:  # 애호박

        if pl_step == "영양생장":
            class_code = 35

        elif pl_step == "생육기":
            class_code = 36

        elif pl_step == "착과기":
            class_code = 37

        elif pl_step == "수확기":
            class_code = 38

    elif pl_code == 16:  # 딸기

        if pl_step == "꽃눈분화기":
            class_code = 39

        elif pl_step == "개화기":
            class_code = 40

        elif pl_step == "수확기":
            class_code = 41

    elif pl_code == 18:  # 토마토

        if pl_step == "정식기":
            class_code = 42

        elif pl_step == "영양생장":
            class_code = 43

        elif pl_step == "생육기":
            class_code = 44

        elif pl_step == "착과기":
            class_code = 45

        elif pl_step == "수확기":
            class_code = 46

    return class_code


def createFolder(directory):
    try:
        if not os.path.exists(directory):
            os.makedirs(directory)
    except OSError:
        print ('Error: Creating directory. ' + directory)



output_path = 'C:/Users/rgy63/PycharmProjects/YOLOv5/farm_data/Validation/tomato_yolo_label/'
createFolder(output_path)

json_path = "C:/Users/rgy63/PycharmProjects/YOLOv5/farm_data/Validation/tomato_label/"
json_list = os.listdir(json_path)

img_path = "C:/Users/rgy63/PycharmProjects/YOLOv5/farm_data/Validation/tomato_raw/"
img_list = os.listdir(img_path)

for i in range(len(json_list)):
    json_file = json_path + json_list[i]
    img_file = img_path + img_list[i]
    output_file = output_path + json_list[i].strip(".json") + ".txt"

    with open(json_file, 'r', encoding='UTF8') as f:
        json_data = json.load(f)

    w, h = img_parse(img_file)
    # print("w : {}, h : {}, c : {}".format(w, h, c))
    pl_code, pl_step, bbox_list = json_parse(json_data)
    # print("pl_code : {}, pl_step : {}, bbox : {}".format(pl_code, pl_step, bbox_list))

    yolo_list = []

    for bbox in bbox_list:
        dw = 1. / w
        dh = 1. / h

        # xmin + xmin + w / 2
        cx = (bbox[0] + bbox[0] + bbox[2]) / 2.0
        # ymin + ymin + w / 2
        cy = (bbox[1] + bbox[1] + bbox[3]) / 2.0

        yolo_x = cx * dw
        yolo_w = bbox[2] * dw
        yolo_y = cy * dh
        yolo_h = bbox[3] * dh

        yolo = [str(farm_class_classify(int(pl_code), pl_step)), str(round(yolo_x, 3)), str(round(yolo_y, 3)), str(round(yolo_w, 3)),
                str(round(yolo_h, 3))]
        # print(yolo)

        yolo_list.append(" ".join(yolo))

    # print(yolo_list)

    with open(output_file, 'w', encoding='UTF8') as f:
        f.writelines("\n".join(yolo_list))

    print(output_file + " done!")


