import json
from PIL import Image
import os
import re

#json 파싱
def json_parse_syllable(json_data):
    word_list = []
    jsonArray = json_data.get("annotations")
    for list in jsonArray:
        if list.get("attributes").get("type") == "글자(음절)":
            word_list.append(list.get("text"))

    return word_list

def json_parse_word(json_data):
    word_list = []
    jsonArray = json_data.get("annotations")
    for list in jsonArray:
        if list.get("attributes").get("type") == "단어(어절)":
            word_list.append(list.get("text"))

    return word_list

def json_parse_sen(json_data):
    word_list = []
    jsonArray = json_data.get("annotations")
    for list in jsonArray:
        if list.get("attributes").get("type") == "문장":
            filename = list.get("text")
            filename = re.sub("[\/:*?\"<>|]", "", filename)
            word_list.append(filename)

    return word_list

def make_new_image(img_file , output_path):
    # img = cv2.imread(img_file)
    img = Image.open(img_file)
    img.save(output_path)

def createFolder(directory):
    try:
        if not os.path.exists(directory):
            os.makedirs(directory)
    except OSError:
        print ('Error: Creating directory. ' +  directory)



output_path = 'C:/Users/rgy63/PycharmProjects/json_parsing/out_val_word/'
createFolder(output_path)

json_path = "C:/Users/rgy63/PycharmProjects/json_parsing/sws_data/"
json_file = json_path + "printed_data_info.json"

img_path_syllable = "C:/Users/rgy63/PycharmProjects/json_parsing/sws_data/01_printed_syllable_images/syllable/"
img_path_word = "C:/Users/rgy63/PycharmProjects/json_parsing/sws_data/01_printed_word_images/word/"
img_path_sen = "C:/Users/rgy63/PycharmProjects/json_parsing/sws_data/01_printed_sentence_images/sentence/"
img_list = os.listdir(img_path_word)

with open(json_file, 'r', encoding='UTF8') as f:
    json_data = json.load(f)

json_list = json_parse_word(json_data)

for i in range(len(img_list)):
    img_file = img_path_word + img_list[i]
    output_file_path = output_path + json_list[i] + "_" + str(i) + ".jpg"

    make_new_image(img_file, output_file_path)
    print(str(i))
    if i == 25000:
        break;
